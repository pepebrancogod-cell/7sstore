import { createClient } from '@/lib/supabase'
import Link from 'next/link'

export default async function ProductPage({ params }: { params: { slug: string }}) {
  const supa = createClient()
  const { data: product } = await supa.from('products').select('*').eq('slug', params.slug).single()
  if (!product) return <div>Produto não encontrado.</div>

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <img src={product.image_url ?? 'https://picsum.photos/seed/'+product.id+'/800/600'} alt={product.name} className="w-full h-auto rounded-2xl" />
      <div className="space-y-4">
        <h1 className="text-3xl font-semibold">{product.name}</h1>
        <p className="text-white/70">{product.description}</p>
        <div className="text-2xl font-bold">R$ {(product.price_cents/100).toFixed(2)}</div>
        <form action="/api/checkout/session" method="POST">
          <input type="hidden" name="product_id" value={product.id} />
          <button className="btn">Pagar com Pix</button>
        </form>
        <Link href="/produtos" className="underline">Voltar</Link>
      </div>
    </div>
  )
}
