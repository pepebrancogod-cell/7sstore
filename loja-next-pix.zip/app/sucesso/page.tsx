export default function Sucesso() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Pagamento recebido! 🎉</h1>
      <p className="text-white/70">Seu pagamento via Pix foi confirmado. Você receberá os detalhes por email.</p>
    </div>
  )
}
