import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createClient } from '@/lib/supabase'

export async function POST(req: Request) {
  const form = await req.formData()
  const product_id = form.get('product_id') as string
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })
  const supa = createClient()
  const { data: product } = await supa.from('products').select('*').eq('id', product_id).single()
  if (!product) return NextResponse.json({ error: 'Produto inválido' }, { status: 400 })

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['pix'],
    line_items: [{
      price_data: {
        currency: 'brl',
        product_data: { name: product.name, description: product.description },
        unit_amount: product.price_cents,
      },
      quantity: 1
    }],
    success_url: process.env.NEXT_PUBLIC_SUCCESS_URL! + '?session_id={CHECKOUT_SESSION_ID}',
    cancel_url: process.env.NEXT_PUBLIC_CANCEL_URL!,
  })

  return NextResponse.redirect(session.url!, { status: 303 })
}
