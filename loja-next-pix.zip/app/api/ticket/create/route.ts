import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase'

export async function POST(req: Request) {
  const supa = createClient()
  const { data: { user } } = await supa.auth.getUser()
  if (!user) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  const form = await req.formData()
  const title = String(form.get('title') || '')
  const body = String(form.get('body') || '')
  const { error } = await supa.from('tickets').insert({ title, body, user_id: user.id, status: 'aberto' })
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.redirect(new URL('/suporte', req.url), { status: 303 })
}
