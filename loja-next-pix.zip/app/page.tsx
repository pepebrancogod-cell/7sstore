export default function Home() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Bem-vindo à {process.env.STORE_NAME ?? 'Minha Loja PB'}</h1>
      <p className="text-white/70">Tema preto e branco, com login antes de acessar áreas internas, suporte e pagamento via PIX.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="/produtos" className="card">Ver Produtos</a>
        <a href="/suporte" className="card">Abrir Suporte</a>
        <a href={process.env.NEXT_PUBLIC_DISCORD_URL} className="card" target="_blank">Entrar no Discord</a>
      </div>
    </div>
  )
}
