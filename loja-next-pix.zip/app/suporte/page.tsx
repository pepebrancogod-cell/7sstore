import { createClient } from '@/lib/supabase'
import Link from 'next/link'

export default async function SuportePage() {
  const supa = createClient()
  const { data: { user } } = await supa.auth.getUser()
  if (!user) {
    return <div>Faça login para abrir tickets de suporte.</div>
  }
  const { data: tickets } = await supa.from('tickets').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Suporte</h1>
      <form action="/api/ticket/create" method="POST" className="card space-y-3">
        <input name="title" placeholder="Assunto" required />
        <textarea name="body" placeholder="Descreva o problema" rows={5} required />
        <button className="btn">Abrir ticket</button>
      </form>
      <div className="space-y-3">
        {tickets?.map((t:any)=>(
          <div key={t.id} className="card">
            <div className="font-semibold">{t.title}</div>
            <div className="text-white/70">{t.body}</div>
            <div className="text-white/50 text-sm">Status: {t.status}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
