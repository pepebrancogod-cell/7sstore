export default function Carrinho() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Carrinho</h1>
      <p className="text-white/70">Você cancelou o checkout. Continue comprando na loja.</p>
    </div>
  )
}
