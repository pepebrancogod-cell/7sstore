import { createClient } from '@/lib/supabase'

export default async function DashboardPage() {
  const supa = createClient()
  const { data: { user } } = await supa.auth.getUser()
  if (!user) return <div>Sem acesso</div>
  const { data: profile } = await supa.from('profiles').select('role').eq('id', user.id).single()
  if (!profile || (profile.role !== 'admin' && profile.role !== 'support')) return <div>Sem permissão</div>

  const { data: tickets } = await supa.from('tickets').select('*').order('created_at', { ascending: false })
  const { data: products } = await supa.from('products').select('*').order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard (Suporte/ADM)</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <div className="font-semibold mb-3">Tickets recentes</div>
          <div className="space-y-2 max-h-[400px] overflow-auto pr-2">
            {tickets?.map((t:any)=>(
              <div key={t.id} className="border-b border-white/10 pb-2">
                <div className="text-sm text-white/60">{t.id}</div>
                <div className="font-medium">{t.title}</div>
                <div className="text-white/60 text-sm">Status: {t.status}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <div className="font-semibold mb-3">Produtos</div>
          <div className="space-y-2">
            {products?.map((p:any)=>(
              <div key={p.id} className="flex items-center justify-between gap-2 border-b border-white/10 pb-2">
                <div className="font-medium">{p.name}</div>
                <div>R$ {(p.price_cents/100).toFixed(2)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
