import './globals.css'
import Navbar from '@/components/Navbar'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: process.env.STORE_NAME ?? 'Minha Loja PB',
  description: 'Loja com login, suporte e PIX',
  icons: [{ rel: 'icon', url: '/favicon.svg' }]
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-br">
      <body>
        <Navbar />
        <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      </body>
    </html>
  )
}
