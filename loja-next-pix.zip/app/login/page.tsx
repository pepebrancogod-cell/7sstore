'use client'
import { useState } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function LoginPage() {
  const supa = createClient()
  const router = useRouter()
  const params = useSearchParams()
  const redirect = params.get('redirect') || '/'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const login = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await supa.auth.signInWithPassword({ email, password })
    if (error) alert(error.message)
    else router.push(redirect)
  }

  const signup = async () => {
    const { error } = await supa.auth.signUp({ email, password })
    if (error) alert(error.message)
    else alert('Cadastro feito! Verifique seu email se necessário e faça login.')
  }

  return (
    <div className="max-w-md mx-auto space-y-5">
      <h1 className="text-2xl font-semibold">Entrar</h1>
      <form onSubmit={login} className="space-y-3">
        <div className="space-y-1">
          <label>Email</label>
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        </div>
        <div className="space-y-1">
          <label>Senha</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        </div>
        <div className="flex items-center gap-3">
          <button type="submit" className="btn">Entrar</button>
          <button type="button" className="btn" onClick={signup}>Criar conta</button>
        </div>
      </form>
    </div>
  )
}
