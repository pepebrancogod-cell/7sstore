import { createClient } from '@/lib/supabase'
import ProductCard from '@/components/ProductCard'

export default async function ProdutosPage() {
  const supa = createClient()
  const { data: products } = await supa.from('products').select('*').order('created_at', { ascending: false })
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Produtos</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products?.map((p:any)=> <ProductCard key={p.id} product={p} />)}
      </div>
    </div>
  )
}
