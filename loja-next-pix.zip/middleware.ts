import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export const config = {
  matcher: ['/dashboard/:path*', '/suporte/:path*']
}

export async function middleware(req: NextRequest) {
  const supa = require('./lib/supabase')
  const client = supa.createClient()
  const { data: { user } } = await client.auth.getUser()
  if (!user) {
    const loginUrl = new URL('/login', req.url)
    loginUrl.searchParams.set('redirect', req.nextUrl.pathname)
    return NextResponse.redirect(loginUrl)
  }
  return NextResponse.next()
}
