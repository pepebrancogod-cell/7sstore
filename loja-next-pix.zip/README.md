# Loja Next.js (PB) com Login, Suporte e PIX (Stripe)

Tema **preto e branco**, com:
- Tela de **login** (Supabase Auth).
- **Papéis**: `member`, `support`, `admin`.
- **Suporte** (tickets) + **Dashboard** protegido (suporte/adm).
- **Produtos** no Supabase.
- **Pagamento PIX** via **Stripe Checkout** (QR Code automático).
- Link do **Discord** fixo.

## 1) Preparar Supabase
1. Crie um projeto em https://supabase.com
2. Em **Table editor**, crie as tabelas com o SQL:

```sql
-- Roles
create type user_role as enum ('member','support','admin');

-- Profiles (1:1 com auth.users)
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role user_role not null default 'member',
  created_at timestamp with time zone default now()
);
alter table profiles enable row level security;
create policy "perfil visível para o próprio usuário"
  on profiles for select using (auth.uid() = id);
create policy "admin pode ver tudo"
  on profiles for all using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Products
create table products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  image_url text,
  price_cents integer not null check (price_cents > 0),
  created_at timestamp with time zone default now()
);
alter table products enable row level security;
create policy "leitura pública de produtos" on products for select using (true);

-- Tickets de suporte
create table tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users not null,
  title text not null,
  body text not null,
  status text not null default 'aberto',
  created_at timestamp with time zone default now()
);
alter table tickets enable row level security;
create policy "usuário lê seus tickets" on tickets for select using (auth.uid() = user_id);
create policy "usuário cria ticket" on tickets for insert with check (auth.uid() = user_id);
create policy "suporte/admin vê tudo" on tickets for all using (
  exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('support','admin'))
);
```

3. Em **Authentication → Providers**, habilite email/senha.
4. Em **Project settings → API**, copie:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon key` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 2) Stripe com Pix
1. Crie conta em https://stripe.com e **ative Pix** nas configurações de *Payment methods*.
2. Pegue a **Secret key** e **Webhook signing secret**.
3. Crie os envs (copie `.env.local.example` → `.env.local`).

> Observação: O Stripe exibe o **QR Code Pix automaticamente** no **Checkout** quando Pix está habilitado. Você não precisa gerar QR na mão. Consulte a doc: *Pix payments* (Stripe).

## 3) Rodar local
```bash
pnpm i  # ou npm i / yarn
pnpm dev
```

## 4) Publicar (Vercel)
- Configure as variáveis de ambiente na Vercel.
- Aponte o domínio.

## 5) Personalizações
- **Ícone da loja**: troque `public/favicon.svg` pelo seu `.ico`/`.png`/`.svg` com o mesmo nome.
- **Discord**: ajuste `NEXT_PUBLIC_DISCORD_URL` no `.env`.
- **Nome da loja**: `STORE_NAME` no `.env` (ou `metadata.title` no `app/layout.tsx`).

## 6) Observações importantes
- O `.zip` que você enviou é um **build estático**; para autenticação/PIX real precisamos de **código-fonte**. Este projeto aqui é pronto para uso, com o mesmo estilo PB e todos os recursos pedidos.
- Se preferir **Efí/Gerencianet** ou **Mercado Pago** no lugar de Stripe, trocamos a rota `/api/checkout/session` facilmente.
