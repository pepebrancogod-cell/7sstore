import { createBrowserClient, createServerClient, isBrowser } from '@supabase/ssr'

export const createClient = () => {
  if (isBrowser()) {
    return createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )
  }
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: () => {
        // Minimal cookie interface for SSR
        const store = new Map<string, string>()
        return {
          getAll: () => Array.from(store).map(([name, value]) => ({ name, value })),
          setAll: (cookies) => cookies.forEach(({ name, value }) => store.set(name, value)),
        }
      }}
  )
}
