export type Role = 'member' | 'support' | 'admin'
export const ROLES: Role[] = ['member', 'support', 'admin']
export const rolePriority: Record<Role, number> = { member: 1, support: 2, admin: 3 }
