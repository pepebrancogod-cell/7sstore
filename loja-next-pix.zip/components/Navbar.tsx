'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase'

export default function Navbar() {
  const [user, setUser] = useState<any>(null)
  const supa = createClient()
  useEffect(() => {
    supa.auth.getUser().then(({ data }) => setUser(data.user))
  }, [])
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-black/70 backdrop-blur">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-3">
        <Link href="/" className="flex items-center gap-2">
          <img src="/favicon.svg" alt="logo" className="h-8 w-8" />
          <span className="font-bold tracking-tight">{process.env.NEXT_PUBLIC_STORE_NAME ?? 'Minha Loja PB'}</span>
        </Link>
        <nav className="ml-auto flex items-center gap-3">
          <Link href="/produtos" className="btn">Produtos</Link>
          <Link href="/suporte" className="btn">Suporte</Link>
          <a href={process.env.NEXT_PUBLIC_DISCORD_URL} target="_blank" className="btn" rel="noreferrer">Discord</a>
          {user ? (
            <>
              <Link href="/dashboard" className="btn">Dashboard</Link>
              <button onClick={() => supa.auth.signOut()} className="btn">Sair</button>
            </>
          ) : (
            <Link href="/login" className="btn">Entrar</Link>
          )}
        </nav>
      </div>
    </header>
  )
}
