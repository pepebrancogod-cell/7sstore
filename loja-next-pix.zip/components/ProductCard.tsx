import Link from 'next/link'

export default function ProductCard({ product }: { product: any }) {
  return (
    <div className="card space-y-3">
      <img src={product.image_url ?? 'https://picsum.photos/seed/'+product.id+'/600/400'} alt={product.name} className="w-full h-48 object-cover rounded-xl" />
      <div className="text-lg font-semibold">{product.name}</div>
      <div className="text-white/70">{product.description}</div>
      <div className="flex items-center justify-between">
        <span className="text-xl font-bold">R$ {(product.price_cents/100).toFixed(2)}</span>
        <Link href={`/produto/${product.slug}`} className="btn">Ver / Comprar</Link>
      </div>
    </div>
  )
}
